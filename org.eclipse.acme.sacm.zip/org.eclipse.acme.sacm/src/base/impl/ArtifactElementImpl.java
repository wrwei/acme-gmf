/**
 */
package base.impl;

import base.ArtifactElement;
import base.Base_Package;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Artifact Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class ArtifactElementImpl extends ModelElementImpl implements ArtifactElement {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArtifactElementImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Base_Package.Literals.ARTIFACT_ELEMENT;
	}

} //ArtifactElementImpl
