/**
 */
package base;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Description</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see base.Base_Package#getDescription()
 * @model
 * @generated
 */
public interface Description extends UtilityElement {
} // Description
