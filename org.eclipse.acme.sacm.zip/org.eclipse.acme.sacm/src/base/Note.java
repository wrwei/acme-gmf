/**
 */
package base;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Note</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see base.Base_Package#getNote()
 * @model
 * @generated
 */
public interface Note extends UtilityElement {
} // Note
