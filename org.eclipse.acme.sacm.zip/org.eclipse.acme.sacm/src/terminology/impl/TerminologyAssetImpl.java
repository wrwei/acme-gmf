/**
 */
package terminology.impl;

import org.eclipse.emf.ecore.EClass;

import terminology.TerminologyAsset;
import terminology.Terminology_Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Terminology Asset</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class TerminologyAssetImpl extends TerminologyElementImpl implements TerminologyAsset {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TerminologyAssetImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Terminology_Package.Literals.TERMINOLOGY_ASSET;
	}

} //TerminologyAssetImpl
