/**
 */
package terminology;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Terminology Asset</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see terminology.Terminology_Package#getTerminologyAsset()
 * @model abstract="true"
 * @generated
 */
public interface TerminologyAsset extends TerminologyElement {
} // TerminologyAsset
