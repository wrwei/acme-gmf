/**
 */
package terminology;

import base.ArtifactElement;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Terminology Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see terminology.Terminology_Package#getTerminologyElement()
 * @model abstract="true"
 * @generated
 */
public interface TerminologyElement extends ArtifactElement {
} // TerminologyElement
