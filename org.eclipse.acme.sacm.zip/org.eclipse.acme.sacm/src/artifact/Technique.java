/**
 */
package artifact;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Technique</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see artifact.Artifact_Package#getTechnique()
 * @model
 * @generated
 */
public interface Technique extends ArtifactAsset {
} // Technique
