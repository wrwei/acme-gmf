/**
 */
package artifact.impl;

import artifact.Artifact_Package;
import artifact.Technique;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Technique</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class TechniqueImpl extends ArtifactAssetImpl implements Technique {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TechniqueImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Artifact_Package.Literals.TECHNIQUE;
	}

} //TechniqueImpl
