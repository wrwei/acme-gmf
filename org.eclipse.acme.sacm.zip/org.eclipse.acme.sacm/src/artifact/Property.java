/**
 */
package artifact;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Property</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see artifact.Artifact_Package#getProperty()
 * @model
 * @generated
 */
public interface Property extends ArtifactAsset {
} // Property
