/**
 */
package artifact;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Resource</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see artifact.Artifact_Package#getResource()
 * @model
 * @generated
 */
public interface Resource extends ArtifactAsset {
} // Resource
