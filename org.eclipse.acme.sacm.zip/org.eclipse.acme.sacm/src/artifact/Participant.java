/**
 */
package artifact;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Participant</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see artifact.Artifact_Package#getParticipant()
 * @model
 * @generated
 */
public interface Participant extends ArtifactAsset {
} // Participant
