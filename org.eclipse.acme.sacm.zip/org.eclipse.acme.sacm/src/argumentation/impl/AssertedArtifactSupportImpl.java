/**
 */
package argumentation.impl;

import argumentation.Argumentation_Package;
import argumentation.AssertedArtifactSupport;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Asserted Artifact Support</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AssertedArtifactSupportImpl extends AssertedRelationshipImpl implements AssertedArtifactSupport {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AssertedArtifactSupportImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Argumentation_Package.Literals.ASSERTED_ARTIFACT_SUPPORT;
	}

} //AssertedArtifactSupportImpl
