/**
 */
package argumentation.impl;

import argumentation.Argumentation_Package;
import argumentation.AssertedArtifactContext;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Asserted Artifact Context</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AssertedArtifactContextImpl extends AssertedRelationshipImpl implements AssertedArtifactContext {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AssertedArtifactContextImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Argumentation_Package.Literals.ASSERTED_ARTIFACT_CONTEXT;
	}

} //AssertedArtifactContextImpl
