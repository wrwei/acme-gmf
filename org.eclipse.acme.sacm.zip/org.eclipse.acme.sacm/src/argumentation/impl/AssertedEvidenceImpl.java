/**
 */
package argumentation.impl;

import argumentation.Argumentation_Package;
import argumentation.AssertedEvidence;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Asserted Evidence</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AssertedEvidenceImpl extends AssertedRelationshipImpl implements AssertedEvidence {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AssertedEvidenceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Argumentation_Package.Literals.ASSERTED_EVIDENCE;
	}

} //AssertedEvidenceImpl
