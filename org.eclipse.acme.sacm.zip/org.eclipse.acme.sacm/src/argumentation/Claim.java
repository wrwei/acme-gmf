/**
 */
package argumentation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Claim</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see argumentation.Argumentation_Package#getClaim()
 * @model
 * @generated
 */
public interface Claim extends Assertion {
} // Claim
