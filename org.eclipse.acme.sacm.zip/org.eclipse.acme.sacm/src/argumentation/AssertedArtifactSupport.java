/**
 */
package argumentation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Asserted Artifact Support</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see argumentation.Argumentation_Package#getAssertedArtifactSupport()
 * @model
 * @generated
 */
public interface AssertedArtifactSupport extends AssertedRelationship {
} // AssertedArtifactSupport
