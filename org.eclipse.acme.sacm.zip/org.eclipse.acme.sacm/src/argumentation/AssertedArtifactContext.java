/**
 */
package argumentation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Asserted Artifact Context</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see argumentation.Argumentation_Package#getAssertedArtifactContext()
 * @model
 * @generated
 */
public interface AssertedArtifactContext extends AssertedRelationship {
} // AssertedArtifactContext
