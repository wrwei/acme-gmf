/**
 */
package argumentation;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Asserted Context</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see argumentation.Argumentation_Package#getAssertedContext()
 * @model
 * @generated
 */
public interface AssertedContext extends AssertedRelationship {
} // AssertedContext
